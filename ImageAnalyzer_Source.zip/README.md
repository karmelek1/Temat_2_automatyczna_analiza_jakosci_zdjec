# Image Quality Analyzer

## Description
This tool analyzes images from a URL or local path, displaying histograms for RGB channels and luminance, and providing a quality assessment (exposure, contrast, etc.).

## Prerequisites
- Python 3.x installed on the system.

## Installation
1. Open a terminal/command prompt in this folder.
2. Install the required libraries using pip:
   ```
   pip install -r requirements.txt
   ```

## How to Run
Run the script using Python:
```
python analyze_image.py
```
