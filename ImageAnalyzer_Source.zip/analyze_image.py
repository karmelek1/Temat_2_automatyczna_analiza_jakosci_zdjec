import cv2
import numpy as np
import matplotlib.pyplot as plt
import requests
from io import BytesIO

def download_image(url):
    try:
        # Add headers to mimic a browser
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        # Check permission/availability with a HEAD request first or just GET
        # Using GET directly to capture content
        print(f"Connecting to {url}...")
        response = requests.get(url, headers=headers, timeout=10)
        
        # Check if site allows to load (status code)
        if response.status_code != 200:
            print(f"Failed to access site. Status Code: {response.status_code}")
            return None
            
        # Check if strictly an image
        content_type = response.headers.get('Content-Type', '')
        if 'image' not in content_type:
            print(f"URL does not appear to be an image. Content-Type: {content_type}")
            return None

        # Create a numpy array from the byte stream
        image_array = np.asarray(bytearray(response.content), dtype=np.uint8)
        # Decode the image
        image = cv2.imdecode(image_array, cv2.IMREAD_COLOR)
        
        if image is None:
            print("Error: Could not decode image. It might not be a valid image format.")
            return None
            
        print("Image downloaded and decoded successfully.")
        return image
    except requests.exceptions.RequestException as e:
        print(f"Error downloading image: {e}")
        return None
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return None

def analyze_histogram_properties(hist, total_pixels):
    """
    Analyzes a single channel histogram to determine exposure and contrast issues.
    hist: 256-element array of pixel counts
    total_pixels: total number of pixels in image
    """
    # Normalize histogram to probabilities
    hist_prob = hist.flatten() / total_pixels
    
    # Define ranges
    shadows_threshold = 30
    highlights_threshold = 225
    
    shadow_density = np.sum(hist_prob[:shadows_threshold])
    highlight_density = np.sum(hist_prob[highlights_threshold:])
    
    # Clipping (Spikes at 0 or 255)
    clipping_shadows = hist_prob[0] > 0.02  # >2% pixels are pure black
    clipping_highlights = hist_prob[255] > 0.02 # >2% pixels are pure white
    
    issues = []
    
    if clipping_shadows:
        issues.append("Clipping in Shadows (Blacks defined)")
    if clipping_highlights:
        issues.append("Clipping in Highlights (Whites defined)")
        
    if shadow_density > 0.4 and highlight_density < 0.05:
        issues.append("Underexposed (Too Dark)")
    elif highlight_density > 0.4 and shadow_density < 0.05:
        issues.append("Overexposed (Too Bright)")
        
    # Contrast: Check standard deviation and width
    # Calculate non-zero range roughly
    non_zeros = np.where(hist_prob > 0.001)[0] # Threshold for "significant" presence
    if len(non_zeros) > 0:
        width = non_zeros[-1] - non_zeros[0]
        if width < 50:
            issues.append("Low Contrast (Narrow Histogram)")
    
    return issues

def analyze_quality_and_plot_histogram(image):
    if image is None:
        return

    # Dimensions
    height, width, channels = image.shape
    total_pixels = height * width
    
    # 1. Grayscale Analysis (Luminance) for overall structure
    gray_image = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    gray_hist = cv2.calcHist([gray_image], [0], None, [256], [0, 256])
    
    # Analyze Grayscale Quality
    quality_notes = analyze_histogram_properties(gray_hist, total_pixels)
    
    quality_status = "Good Exposure/Contrast" if not quality_notes else "Issues Detected: " + "; ".join(quality_notes)
    
    print(f"\n--- Image Analysis Report ---")
    print(f"Quality Assessment: {quality_status}")
    
    # Plotting
    plt.figure(figsize=(16, 12))
    
    # Plot 1: Original Image
    plt.subplot(3, 2, 1)
    plt.title("Original Image")
    rgb_image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    plt.imshow(rgb_image)
    plt.axis('off')
    
    # Plot 2: Grayscale Histogram (Luminance)
    plt.subplot(3, 2, 2)
    plt.title("Luminance (Grayscale) Histogram")
    plt.xlabel("Pixel Value")
    plt.ylabel("Frequency")
    plt.plot(gray_hist, color='black', label='Luminance')
    plt.fill_between(range(256), gray_hist.flatten(), color='gray', alpha=0.3)
    plt.xlim([0, 256])
    plt.legend()
    
    # Plot 3-5: RGB Channels Separated
    colors = ('b', 'g', 'r')
    titles = ('Blue Channel', 'Green Channel', 'Red Channel')
    
    # I will plot R, G, B in the next 3 slots
    for i, color in enumerate(colors):
        plt.subplot(3, 2, 3 + i)
        plt.title(titles[i])
        hist = cv2.calcHist([image], [i], None, [256], [0, 256])
        plt.plot(hist, color=color)
        plt.xlim([0, 256])
        plt.xlabel("Pixel Value")
        plt.ylabel("Frequency")
    
    # Plot 6: Text Analysis
    plt.subplot(3, 2, 6)
    plt.axis('off')
    plt.title("Detailed Quality Report")
    
    # Text Analysis
    report_text = f"Quality Status:\n{quality_status}\n\n"
    report_text += "Basic Statistics:\n"
    report_text += f"Mean Luminance: {np.mean(gray_image):.1f}\n"
    report_text += f"Std Dev (Contrast): {np.std(gray_image):.1f}\n"
    
    plt.text(0.05, 0.5, report_text, fontsize=11, verticalalignment='center', wrap=True)

    plt.tight_layout()
    output_file = "analysis_result.png"
    plt.savefig(output_file)
    print(f"Histogram saved to {output_file}")
    # print("Displaying histogram... (Close the window to exit)")
    # plt.show() # Disabled for non-interactive running if needed, but user didn't say no.

if __name__ == "__main__":
    print("Image Quality Analyzer")
    print("----------------------")
    
    # Default URL from request ( below commented link to good quality image)
    default_url = "https://images.unsplash.com/photo-1587987746776-302404b98970?q=80&w=987&auto=format&fit=crop&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    # Good quality image: "https://upload.wikimedia.org/wikipedia/commons/thumb/e/ec/Mona_Lisa%2C_by_Leonardo_da_Vinci%2C_from_C2RMF_retouched.jpg/1200px-Mona_Lisa%2C_by_Leonardo_da_Vinci%2C_from_C2RMF_retouched.jpg"
    
    # Code now just uses this default URL as requested ("present in the code")
    print(f"Using default URL defined in code: {default_url}")
    target_url = default_url
    
    img = download_image(target_url)
    
    if img is not None:
        analyze_quality_and_plot_histogram(img)
